import { useState } from "react";

export const Wishlist = () => {
  return (
    <>
      <h3>Wishlist</h3>
    </>
  );
};
